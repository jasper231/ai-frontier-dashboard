import { categories } from '@/data/frontier';
import { CategorySection } from '@/components/category-section';
import { ViewFilters } from '@/components/view-filters';
import { TopSignals } from '@/components/top-signals';
export default function Home() {
  return <><a className="skip-link" href="#main">跳转到内容</a><header className="topbar"><a className="brand" href="#">FRONTIER <span>/ PERSONAL INTELLIGENCE</span></a><span className="edition">LOCAL EDITION</span></header><div className="shell"><aside className="sidebar"><div className="nav-label">观察领域 / 05</div><nav aria-label="栏目导航">{categories.map((c,i)=><a href={`#${c.id}`} key={c.id}><span className="nav-index">0{i+1}</span>{c.title}</a>)}</nav><p className="sidebar-note">独立观察。<br/>持续形成判断。</p></aside><main id="main"><div className="intro"><div className="eyebrow">个人前沿科技情报终端</div><h1>AI Frontier</h1><p>Track what matters. Understand why it matters.</p></div><div className="brief-toolbar"><ViewFilters/><span className="demo-note">示例内容 · 筛选仅切换选中状态</span></div><TopSignals/><div className="feed-title"><span>FIELD NOTES / 详细浏览</span><span>05 领域 · 10 条精选</span></div>{categories.map((c,i)=><CategorySection category={c} index={i} key={c.id}/>)}<footer><span>FRONTIER / 独立观察，持续思考。</span><span>本地示例内容与日期 · 非实时新闻</span></footer></main></div></>;
}
