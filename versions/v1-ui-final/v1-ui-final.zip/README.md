# AI Frontier Dashboard

Next.js App Router + TypeScript 个人技术观察台，包含五个栏目、15 条本地中文示例。内容与日期用于展示，不是实时新闻。无需数据库、API Key、环境变量或远程字体。

## 运行

需要 Node.js 20.9+（推荐 24）。

```bash
npm ci
npm run dev
```

打开 http://localhost:3000。

## 检查

```bash
npm run lint
npm run typecheck
npm run build
```

静态导出目录为 `out/`，可直接托管。生产预览使用 `npx serve out`，静态导出模式不支持 `next start`。

## 结构

- `src/app/page.tsx`：首页与栏目导航
- `src/app/layout.tsx`：语言与 metadata
- `src/app/globals.css`：主题、响应式布局与无障碍焦点
- `src/components/category-section.tsx`：栏目与卡片组件
- `src/data/frontier.ts`：数据类型与 15 条示例
- `public/favicon.svg`：图标
- `next.config.ts`：静态导出
- `eslint.config.mjs`、`tsconfig.json`：检查配置

## 下一步

从 `src/data/frontier.ts` 替换为个人笔记；真实新闻可增加来源链接。确认内容后，将 `out/` 部署至静态托管服务。

## 无 npm 的静态备用版

直接打开 `static-preview/dashboard-standalone.html`（CSS 已内嵌），无需安装依赖。完整静态目录是 `static-preview/`。

```bash
python3 -m http.server 3000 --bind 0.0.0.0 --directory static-preview
```

在允许网络套接字的环境访问 http://localhost:3000。手机需要能访问该机器的网络地址或托管 URL，手机自己的 localhost 不会访问云环境。

`node scripts/create-static.mjs` 可以从现有 TypeScript 数据重新生成静态目录。`artifacts/verification.json` 记录本次实际验证范围。

本环境的限制：HTTP proxy 连接失败，npm 缓存为空，无预装 Next/React；HTTP 服务创建 socket 被沙箱拒绝；Chromium setsockopt 被沙箱拒绝。静态内容数量、日期字段、为什么重要字段、导航目标及生成脚本语法已验证。Next.js 构建和浏览器手机布局尚未验证。
