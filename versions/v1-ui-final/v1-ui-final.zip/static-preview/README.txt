AI Frontier — UI 冻结版

用浏览器打开 index.html，无需 npm、网络或服务器。
CSS、图标与简单选中交互均内嵌，HTML 可独立移动。
Top Signals 文案精简；手机标题增大、正文 16px。
手机端 Why it matters、Long-term impact 和普通卡片分析最多显示两行。
五个栏目默认各 2 条，“查看全部”展开第 3 条。
筛选仅切换选中状态。所有内容为示例，不是实时新闻。
结构与离线资源已检查；本轮未执行手机浏览器实测。
UI 在本轮完成后冻结。
